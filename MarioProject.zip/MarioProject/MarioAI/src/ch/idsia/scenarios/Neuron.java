package ch.idsia.scenarios;

import java.util.Random;
public class Neuron {
double[] inputWeights;
 
public Neuron(Neuron original)
{
inputWeights = new double[original.inputWeights.length];
for(int i=0; i < inputWeights.length; i++)
inputWeights[i] = original.inputWeights[i];
}
public Neuron(int size)
{
inputWeights = new double[size];
// set to random initial weights
Random rand = new Random();
for(int i=0; i < inputWeights.length; i++)
{
inputWeights[i] = rand.nextDouble();
if(rand.nextBoolean())
inputWeights[i] *= -1;
}
}
 
public void mutate()
{
Random rand = new Random();
 
int chosenOne = rand.nextInt(inputWeights.length);
inputWeights[chosenOne] = rand.nextDouble();
if(rand.nextBoolean())
inputWeights[chosenOne] *= -1;
}
 
public int activate(double[] input)
{
double total = 0;
for(int i=0; i < input.length; i++)
{
double inputI = input[i];
total += inputI * inputWeights[i];
}
 
if(total > 0)
return 1;
else
return 0;
}
}
