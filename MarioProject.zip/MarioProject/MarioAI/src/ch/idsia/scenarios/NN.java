package ch.idsia.scenarios;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;
public class NN
{
double score;
Neuron neuron0= new Neuron(15);
Neuron neuron1 = new Neuron(15);
Neuron neuron2 = new Neuron(15);
Neuron neuron3 = new Neuron(15);
Neuron output0 = new Neuron(4);
Neuron output1 = new Neuron(4);
Neuron output2 = new Neuron(4);
Neuron output3 = new Neuron(4);
Neuron output4 = new Neuron(4);
 
public NN()
{
}
public NN(NN original)
{
   neuron0 = new Neuron(original.neuron0);
   neuron1 = new Neuron(original.neuron1);
   neuron2 = new Neuron(original.neuron2);
   neuron3 = new Neuron(original.neuron3);
   output0 = new Neuron(original.output0);
   output1 = new Neuron(original.output1);
   output2 = new Neuron(original.output2);
   output3 = new Neuron(original.output3);
   output4 = new Neuron(original.output4);
}


public boolean[] classify(double[] input)
{
	boolean[] ret = new boolean[5];
	
	for(int i = 0; i < 5; i++)
		ret[i] = false;
	
double[] layer1Output = new double[4];
layer1Output[0] = neuron0.activate(input);
layer1Output[1] = neuron1.activate(input);
layer1Output[2] = neuron2.activate(input);
layer1Output[3] = neuron3.activate(input);
int out1 = output0.activate(layer1Output);
int out2 = output1.activate(layer1Output);
int out3 = output2.activate(layer1Output);
int out4 = output3.activate(layer1Output);
int out5 = output4.activate(layer1Output);
if(out1 == 1)
	ret[0] = true;
if (out2 == 1)
	ret[1] = true;
if (out3 == 1)
	ret[2] = true;
if (out4 == 1)
	ret[3] = true;
if (out5 == 1)
	ret[4] = true;
return ret;
}
}