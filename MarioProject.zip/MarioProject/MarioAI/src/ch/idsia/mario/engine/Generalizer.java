package ch.idsia.mario.engine;

/**
 * Created by IntelliJ IDEA.
 * User: Sergey Karakovskiy, firstname_at_idsia_dot_ch
 * Date: Aug 5, 2009
 * Time: 7:02:42 PM
 * Package: ch.idsia.mario.engine
 */
public interface Generalizer
{
    public byte ZLevelGeneralization(byte el, int ZLevel);
}
