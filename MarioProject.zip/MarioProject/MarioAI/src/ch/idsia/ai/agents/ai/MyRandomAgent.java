package ch.idsia.ai.agents.ai;

import java.util.Random;

import ch.idsia.ai.agents.Agent;
import ch.idsia.mario.environments.Environment;

public class MyRandomAgent extends BasicAIAgent implements Agent {
	
	public MyRandomAgent()
    {
        super("MyRandomAgent");
        reset();
    }

	
	public void setName(String name)
	{
		
	}
	
	private Random R = null;
	public void reset()
	{
		R = new Random();
	}
	
	public boolean[] getAction(Environment observation)
	{
		 boolean[] ret = new boolean[Environment.numberOfButtons];
		 
		 for (int i = 0; i < Environment.numberOfButtons; ++i)
		 {
			 ret[i] = R.nextBoolean();
		 }
		 return ret;
	}
}