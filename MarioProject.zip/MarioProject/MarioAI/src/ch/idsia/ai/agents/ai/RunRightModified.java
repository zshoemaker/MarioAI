package ch.idsia.ai.agents.ai;

import java.util.Random;

import ch.idsia.ai.agents.Agent;
import ch.idsia.mario.engine.sprites.Mario;
import ch.idsia.mario.environments.Environment;

public class RunRightModified extends BasicAIAgent implements Agent {
	
	public RunRightModified()
    {
        super("RunRightModified");
        reset();
    }
	public void setName(String name)
	{

	}
	
	public void reset()
	{
	
	}
	
	public boolean[] getAction(Environment observation)
	{ 
		 boolean[] ret = new boolean[Environment.numberOfButtons];
		 byte[][] levelScene = observation.getCompleteObservation(/*1*/);
		 ret[0] = false;
		 ret[1] = true;
		 ret[2] = false;
		 ret[3] = false;
		 ret[4] = false;
		 if (levelScene[12][12] != -10 || (levelScene[11][12] != 0 && observation.mayMarioJump()))
		 {
			 ret[3] = true;
		 }
		 return ret;
	}
}