package ch.idsia.ai.agents.ai;

import java.util.Random;

import ch.idsia.ai.agents.Agent;
import ch.idsia.mario.environments.Environment;

public class RunRightAgent extends BasicAIAgent implements Agent {
	
	public RunRightAgent()
    {
        super("RunRightAgent");
        reset();
    }

	
	public void setName(String name)
	{
		
	}
	
	public void reset()
	{
	
	}
	
	public boolean[] getAction(Environment observation)
	{
		 boolean[] ret = new boolean[Environment.numberOfButtons];
		 
		 ret[0] = false;
		 ret[1] = true;
		 ret[2] = false;
		 ret[3] = false;
		 ret[4] = false;
		 
		 return ret;
	}
		 
		 
}
