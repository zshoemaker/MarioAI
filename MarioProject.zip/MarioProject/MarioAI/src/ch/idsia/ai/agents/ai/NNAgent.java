package ch.idsia.ai.agents.ai;

import java.util.Random;

import ch.idsia.ai.agents.Agent;
import ch.idsia.mario.environments.Environment;
import ch.idsia.scenarios.NN;

public class NNAgent extends BasicAIAgent implements Agent {
	
	public NNAgent()
    {
       super("NNAgent");
       reset();
    }

	NN NN1 = new NN();
	
	public void setName(String name)
	{
		
	}
	
	private Random R = null;
	public void reset()
	{
		R = new Random();
	}
	
	public boolean[] getAction(Environment observation)
	{
		byte[][] levelScene = observation.getCompleteObservation(/*1*/);
		double[] input = new double[5];
		input[0] = levelScene[12][12];
		input[1] = levelScene[11][12];
		input[2] = levelScene[11][13];
		input[3] = levelScene[12][9];
		input[4] = levelScene[12][13];
		
		
		return NN1.classify(input);
	}
}
